/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ex01;
import java.util.ArrayList;

/**
 *
 * @author MauricioAsenjo
 */
public class Ex01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList <Integer> lista = new ArrayList();
        boolean aux;
        
        Cronometro.start();
        for (int i = 1; i < 1000001; ++i)
        {
            lista.add(i);
        }
        Cronometro.stop();
        
        System.out.println("Tempo para 1.000.000 de inserções");
        System.out.println("Iniciado as..: " + Cronometro.getInic());
        System.out.println("Finalizado as: " + Cronometro.getFim());
        System.out.println("Tempo total..: " + Cronometro.getTotal() + "ms");
        
        Cronometro.start();
        for (int i = 1; i < 100001; ++i)
        {
            aux = lista.contains(i);
        }
        Cronometro.stop();
        
        System.out.println("Tempo para 100.000 consultas");
        System.out.println("Iniciado as..: " + Cronometro.getInic());
        System.out.println("Finalizado as: " + Cronometro.getFim());
        System.out.println("Tempo total..: " + Cronometro.getTotal() + "ms");
    }
    
}
