/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ex01;

/**
 *
 * @author MauricioAsenjo
 */
public class Triangulo implements Comparable<Triangulo> {
    private String base;
    private String altura;

    public Triangulo() {}
    public Triangulo(String _base, String _altura) {base = _base; altura = _altura;}
    public void setBase(String _base) {base=_base;}
    public void setAltura(String _altura) {altura=_altura;}
    public String  getBase() {return base;}
    public String  getAltura() {return altura;}
    public float getArea() {return Float.parseFloat(base)*Float.parseFloat(altura)/2;}
    public int compareTo(Triangulo outro)
    {
        if (this.getArea()<outro.getArea()) return -1;
        if (this.getArea()>outro.getArea()) return 1;
        return 0;
    }
}
