/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ex01;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author MauricioAsenjo
 */
public class Ex01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList <Triangulo> lista = new ArrayList();
        Triangulo t1 = new Triangulo("10","20");
        Triangulo t2 = new Triangulo("5","8");
        Triangulo t3 = new Triangulo("16","24");
        Triangulo t4 = new Triangulo("2","5");
        Triangulo t5 = new Triangulo("20","3");
        
        
        lista.add(t1);
        lista.add(t2);
        lista.add(t3);
        lista.add(t4);
        lista.add(t5);

        System.out.println("Valores originais da lista");
        for (int i =0; i<lista.size(); ++i)
        {
            Triangulo aux = lista.get(i);
            System.out.println(i + ". base = " + aux.getBase() + "\n   altura = " + aux.getAltura()  + "\n   area = " + aux.getArea());
        }
        
        Collections.sort(lista);
        
        System.out.println("Valores da lista após ordenação");
        for (int i =0; i<lista.size(); ++i)
        {
            Triangulo aux = lista.get(i);
            System.out.println(i + ". base = " + aux.getBase() + "\n   altura = " + aux.getAltura()  + "\n   area = " + aux.getArea());
        }
        
        Collections.reverse(lista);
        
        System.out.println("Valores da lista após reversão");
        for (int i =0; i<lista.size(); ++i)
        {
            Triangulo aux = lista.get(i);
            System.out.println(i + ". base = " + aux.getBase() + "\n   altura = " + aux.getAltura()  + "\n   area = " + aux.getArea());
        }


    }
    
}
