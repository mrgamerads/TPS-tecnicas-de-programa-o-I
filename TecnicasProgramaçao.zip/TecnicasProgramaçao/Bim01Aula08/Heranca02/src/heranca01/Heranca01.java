/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca01;

/**
 *
 * @author MauricioAsenjo
 */
public class Heranca01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Anual Joao = new Anual(7,8,9,10);

    System.out.println("P1    = " + Joao.getP1());
    System.out.println("P2    = " + Joao.getP2());
    System.out.println("P1    = " + Joao.getP3());
    System.out.println("P2    = " + Joao.getP4());
    System.out.println("Media = " + Joao.getMedia());
    
    Semestral Maria = new Semestral (7,8);

    System.out.println("P1    = " + Maria.getP1());
    System.out.println("P2    = " + Maria.getP2());
    System.out.println("Media = " + Maria.getMedia());
    }
    
}
