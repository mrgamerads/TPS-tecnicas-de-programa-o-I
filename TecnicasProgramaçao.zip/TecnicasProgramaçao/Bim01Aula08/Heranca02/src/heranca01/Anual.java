/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca01;

/**
 *
 * @author MauricioAsenjo
 */
public class Anual extends Semestral{
  private float p3;
  private float p4;

  public Anual(float _p1, float _p2, float _p3, float _p4)
    {
    super.setP1(_p1);
    super.setP2(_p2);
    p3=_p3;
    p4=_p4;
    }

  public void 	setP3 (float _p3) {p3=_p3;}
  public void 	setP4 (float _p4) {p4=_p4;}
  public float  getP3() {return p3;}
  public float  getP4() {return p4;}
  public float  getMedia() {return (super.getP1()+super.getP2()+p3+p4)/4;}
}
