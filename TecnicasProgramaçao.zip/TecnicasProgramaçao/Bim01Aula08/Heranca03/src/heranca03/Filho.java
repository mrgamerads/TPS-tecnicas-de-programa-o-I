/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca03;

/**
 *
 * @author MauricioAsenjo
 */
public class Filho extends Pai{
private int d;
private String e;

public Filho(int _a, float _b, String _c, int _d, String _e)
    {
    super(_a,_b,_c);
    d=_d;
    e=_e;
    }

  public int soma()       {return super.a+d;}

  public String getTodosDados()
    {
    return super.getTodosDados() + "\n d = " + d + "\n e = " + e;
    }
    
}
