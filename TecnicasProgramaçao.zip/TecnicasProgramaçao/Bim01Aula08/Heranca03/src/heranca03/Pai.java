/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca03;

/**
 *
 * @author MauricioAsenjo
 */
public class Pai {
protected int a;
protected float b;
protected String c;

public Pai() {}
public Pai(int _a, float _b, String _c)
  {
  a=_a;
  b=_b;
  c=_c;
  }

String getTodosDados()
  {
  return ("a = "+a+"\nb = "+b+"\nc = "+c);
  }
    
}
