/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca03;

/**
 *
 * @author MauricioAsenjo
 */
public class Heranca03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Pai   t1 = new Pai(1,2.5f,"Jose");
    Filho t2 = new Filho(1,8.5f,"Joao",2,"Maria");

    System.out.println(t1.getTodosDados());
    System.out.println(t2.getTodosDados());
    System.out.println(t2.soma());
    }
    
}
