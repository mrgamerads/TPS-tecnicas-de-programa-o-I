/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enum03;

/**
 *
 * @author MauricioAsenjo
 */
public class TV {
    private int tamanho;
    private Cores cor;
 
    public TV(int _tamanho, Cores _cor) {
        tamanho = _tamanho;
        cor = _cor;
}
 
    public int getTamanho() {return tamanho;}
    public Cores getCor() {return cor;}
}
     

