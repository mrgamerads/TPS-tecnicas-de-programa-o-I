/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgenum;

/**
 *
 * @author MauricioAsenjo
 */
public enum Moedas {
     Real(3.45f), PesoArgentino(9.20f), PesoUruguaio(28.50f), PesoChileno(681.81f);
     
     private float valor;
     
     Moedas(float _valor) {valor=_valor;}
     public void setValor(float _valor) {valor=_valor;}
     public float getValor() {return valor;}
}
