/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca01;

/**
 *
 * @author MauricioAsenjo
 */
public class Semestral {
  private float p1;
  private float p2;

  public Semestral() {}
  public Semestral(float _p1, float _p2)   {p1=_p1; p2=_p2;}
  public void 	setP1 (float _p1) {p1=_p1;}
  public void 	setP2 (float _p2) {p2=_p2;}
  public float  getP1()         {return p1;}
  public float  getP2()         {return p2;}
  public float  getMedia()      {return (p1+p2)/2;}
    
}
