public class Ex02
  {
  public static void main(String[] args)
    {
    int a=7, b=3;

    System.out.print("a + b = " + (a+b) + "\n");
    System.out.print("a - b = " + (a-b) + "\n");
    System.out.print("a * b = " + (a*b) + "\n");
    System.out.print("a / b = " + (a/b) + "\n");
    System.out.print("a % b = " + (a%b) + "\n");
    // Aqui eu quero uma divis�o de verdade
    System.out.print("++a   = " + (++a) + "\n");
    a=7;
    System.out.print("a++   = " + (a++) + "\n");
    a=7;
    System.out.print("--a   = " + (--a) + "\n");
    a=7;
    System.out.print("a--   = " + (a--) + "\n");
    a=7;
    System.out.print("a+=5  = " + (a+=5) + "\n");
    a=7;
    System.out.print("a-=5  = " + (a-=5) + "\n");
    // Aqui eu quero a raiz quadrada de 2
    }
  }