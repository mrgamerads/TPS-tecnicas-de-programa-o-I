public class Ex04
  {
  public static void main(String[] args)
    {
    int a=5;

    if (a>0 && a<11)
      System.out.println("O numero esta no intervalo [1..10]");
    }
  }