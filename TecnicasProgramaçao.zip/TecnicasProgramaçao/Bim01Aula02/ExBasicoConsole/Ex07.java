import java.util.Scanner;

public class Ex07
  {
  public static void main(String[] args)
    {
    int a,b,op=1;
    Scanner in = new Scanner(System.in);

    System.out.println("Digite um numero...: ");
    a = in.nextInt();
    System.out.println("Digite outro numero: ");
    b = in.nextInt();
    System.out.println("Operador 1(+),2(-),3(*),4(/).: ");
    op = in.nextInt();

    switch(op)
      {
      case 1 : System.out.println(a + " + " + b + " = " + (a+b));
                 break;
      case 2 : System.out.println(a + " - " + b + " = " + (a-b));
                 break;
      case 3 : System.out.println(a + " * " + b + " = " + (a*b));
                 break;
      case 4 : System.out.println(a + " / " + b + " = " + (a/b));
                 break;
      default  : System.out.println("Operador Indevido!!!");
      }
    }
  }