import java.util.Scanner;

public class Ex06
  {
  public static void main(String[] args)
    {
    int a;
    Scanner in = new Scanner(System.in);

    System.out.println("Digite um numero entre [1..31]");
    a = in.nextInt();

    if (a==2 || a==18 || a==29)
      System.out.println("Vc acertou o dia de aniversario de um dos membros da minha familia!");
    else
      System.out.println("Ninguem na minha familia faz aniversario neste dia!");

    }
  }