import java.util.Scanner;

public class Ex05
  {
  public static void main(String[] args)
    {
    String nome;
    Scanner in = new Scanner(System.in);

    System.out.println("Qual seu nome.: ");
    nome = in.nextLine();
    System.out.println("Boa Noite, " + nome + "!");
    }
  }