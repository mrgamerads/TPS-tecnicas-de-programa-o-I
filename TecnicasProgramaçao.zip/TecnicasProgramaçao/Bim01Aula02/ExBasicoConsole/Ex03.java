public class Ex03
  {
  public static void main(String[] args)
    {
    int a=5,b=8;

    if (a>b)
	 System.out.println("O primeiro numero e maior que o segundo");
    else
      if (b>a)
        System.out.println("O segundo numero e maior que o primeiro");
      else
        System.out.println("Os numeros sao iguais!");

    // Resolver o mesmo exerc�cio usando if reduzido ou tern�rio
    }
  }