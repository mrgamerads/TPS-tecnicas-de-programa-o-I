public class Ex01
  {
  public static void main(String[] args)
    {
    // *** Declarando variaveis numericas inteiras ***

    byte  v1=18;
    short v2=345;
    int   v3=1250;
    long  v4=4500;

    // *** Declarando variaveis numericas de ponto flutuante ***

    float  v5=1.5f;
    double v6=0.33;

    // *** Declarando variaveis do tipo caracter ***

    char   v7='M';

    // *** Declarando variaveis do tipo boolean ***

    boolean v8=true;
    boolean v9=false;

    System.out.print("v1 = " + v1 + "\n");
    System.out.print("v2 = " + v2 + "\n");
    System.out.print("v3 = " + v3 + "\n");
    System.out.print("v4 = " + v4 + "\n");
    System.out.print("v5 = " + v5 + "\n");
    System.out.print("v6 = " + v6 + "\n");
    System.out.print("v7 = " + v7 + "\n");
    System.out.print("v8 = " + v8 + "\n");
    System.out.print("v9 = " + v9 + "\n");
    }
  }