import java.util.Scanner;

public class Ex19
  {
  public static void main(String[] args)
    {
    int t;
    int[] x,y,z;
    Scanner in = new Scanner(System.in);

    System.out.println("Qual o tamanho do array.: ");
    t = in.nextInt();
    x = new int[t];

    for (int i=0;i<t;++i)
       x[i]=i+1;

    for (int i=0;i<t;++i)
       System.out.println("x[" + i + "] = " + x[i]);

    y=x;
     for (int i=0;i<t;++i)
       System.out.println("y[" + i + "] = " + y[i]);

    z=x.clone();
    for (int i=0;i<t;++i)
       System.out.println("z[" + i + "] = " + z[i]);



    }
  }