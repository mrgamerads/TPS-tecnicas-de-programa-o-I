import java.util.Scanner;
import java.util.Random;

public class Ex20
  {
  public static void main(String[] args)
    {
    int t, soma=0;
    int[] x;
    Scanner in = new Scanner(System.in);
    Random gerador = new Random();

    System.out.println("Qual o tamanho do array.: ");
    t = in.nextInt();
    x = new int[t];

    for (int i=0;i<t;++i)
       x[i]=gerador.nextInt(10);

    for (int i : x)
       System.out.println(i);

    for (int i : x)
       soma +=i;

    System.out.println(soma);
    }
  }