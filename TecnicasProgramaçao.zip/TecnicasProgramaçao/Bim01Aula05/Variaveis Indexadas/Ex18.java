import java.util.Scanner;

public class Ex18
  {
  public static void main(String[] args)
    {
    int t;
    int[] x;
    Scanner in = new Scanner(System.in);

    System.out.println("Qual o tamanho do array.: ");
    t = in.nextInt();
    x = new int[t];

    for (int i=0;i<t;++i)
       x[i]=i+1;

    for (int i=0;i<t;++i)
       System.out.println("x[" + i + "] = " + x[i]);
    }
  }