public class Ex21
  {
  public static void main(String[] args)
    {
    int[][] x = new int[3][3];
    int k=1;

    for (int i=0;i<3;++i)
       for (int j=0;j<3;++j)
       {
          x[i][j] = k;
          ++k;
       }

    for (int i=0;i<3;++i)
       for (int j=0;j<3;++j)
          System.out.println("x["+i+"][" + j + "] = "+x[i][j]);
    }
  }