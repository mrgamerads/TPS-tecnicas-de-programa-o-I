public class Ex17
  {
  public static void main(String[] args)
    {
    int[] x = {1,2,3,4,5,6,7,8,9,10};

    System.out.println("x[3] = " + x[3]);
    x[3]=61;
    System.out.println("x[3] = " + x[3]);
    System.out.println("Comprimento de x: " + x.length);
    }
  }