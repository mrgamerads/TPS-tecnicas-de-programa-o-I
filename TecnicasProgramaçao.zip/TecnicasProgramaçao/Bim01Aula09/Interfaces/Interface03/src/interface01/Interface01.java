/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interface01;

/**
 *
 * @author MauricioAsenjo
 */
public class Interface01 {

    /**
     * @param args the command line arguments
     */
    
    public static void mostraDados(ObjetoGeometrico _x)
    {
        
        System.out.println("Area do " + _x.getClass().getSimpleName() + " = " + _x.getArea());
        System.out.println("Perimetro do " + _x.getClass().getSimpleName() + " = " + _x.getPerimetro());
    }

    public static void main(String[] args) {
        Circulo C=new Circulo(5);
        Retangulo R=new Retangulo(5,10);
        
        ObjetoGeometrico x = C;
        mostraDados(x);

        x = R;
        mostraDados(x);
        
        mostraDados(C);
        mostraDados(R);
    }
    
}
