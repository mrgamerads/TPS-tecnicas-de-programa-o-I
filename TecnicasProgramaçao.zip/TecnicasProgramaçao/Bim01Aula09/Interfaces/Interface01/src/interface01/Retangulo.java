/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interface01;

/**
 *
 * @author MauricioAsenjo
 */
public class Retangulo implements ObjetoGeometrico {
private float lado1;
private float lado2;

Retangulo(float l1, float l2)   {lado1=l1; lado2=l2;}
public float getArea()          {return lado1*lado2;}
public float getPerimetro()     {return 2*lado1+2*lado2;}
    
}
