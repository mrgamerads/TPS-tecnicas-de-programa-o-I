/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interface01;

/**
 *
 * @author MauricioAsenjo
 */
public class Interface01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Circulo C=new Circulo(5);

        System.out.println("Area do circulo......: "+C.getArea());
        System.out.println("Perimetro do circulo.: "+C.getPerimetro());
        
        Retangulo R=new Retangulo(5,10);

        System.out.println("Area do retangulo......: "+R.getArea());
        System.out.println("Perimetro do retangulo.: "+R.getPerimetro());
       
    }
    
}
