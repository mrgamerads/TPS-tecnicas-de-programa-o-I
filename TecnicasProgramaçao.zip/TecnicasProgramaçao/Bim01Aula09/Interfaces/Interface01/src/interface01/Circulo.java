/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interface01;

/**
 *
 * @author MauricioAsenjo
 */
public class Circulo implements ObjetoGeometrico {
private float raio;

Circulo(float r)         {raio=r;}
public float getArea()          {return PI*raio*raio;}
public float getPerimetro()     {return 2*PI*raio;}
    
}
