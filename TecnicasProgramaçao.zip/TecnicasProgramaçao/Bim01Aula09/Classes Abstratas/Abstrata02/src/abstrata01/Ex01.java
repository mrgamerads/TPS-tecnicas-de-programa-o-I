/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstrata01;

/**
 *
 * @author MauricioAsenjo
 */
public abstract class Ex01 {
  protected int a;
  protected int b;

  public Ex01()
    {
    a=10;
    b=20;
    }

  public final void metodo1()
    {
    ++a;
    ++b;
    }

  public void metodo2()
    {
    System.out.println(a);
    System.out.println(b);
    }

  public abstract void metodo3();
    
}
