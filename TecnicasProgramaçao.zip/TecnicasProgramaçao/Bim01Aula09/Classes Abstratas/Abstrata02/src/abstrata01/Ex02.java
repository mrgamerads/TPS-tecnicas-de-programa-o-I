/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstrata01;

/**
 *
 * @author MauricioAsenjo
 */
public class Ex02 extends Ex01{
  public void metodo4()
    {
    a*=5;
    b*=10;
    }
  
  
  public void metodo3()
    {
    System.out.println("a = "+a+"\nb = "+b);
    }
    
}
