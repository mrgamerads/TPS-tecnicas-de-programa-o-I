/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstrata01;

/**
 *
 * @author MauricioAsenjo
 */
public class Abstrata01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Ex02 x = new Ex02();

    x.metodo1();
    x.metodo2();
    x.metodo3();
    }
    
}
