/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ex01;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author MauricioAsenjo
 */
public class Ex01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList <String> lista = new ArrayList();
        lista.add("Mauricio");
        lista.add("Gilberto");
        lista.add("Cesar");
        lista.add("Ana");
        lista.add("Maria");
        lista.add("Mauricio");
        
        System.out.println(lista);
        Collections.sort(lista);
        System.out.println(lista);
        
        System.out.println("A Ana esta na lista? " + lista.contains("Ana"));
        System.out.println("Qual a posição da Ana na lista? " + lista.indexOf("Ana"));
        lista.remove("Ana");
        System.out.println(lista);
        System.out.println("A Ana esta na lista? " + lista.contains("Ana"));
        System.out.println("Qual a posição da Maria na lista? " + lista.indexOf("Maria"));
    }
    
}
