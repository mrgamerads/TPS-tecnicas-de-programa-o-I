/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ex01;
import java.util.Set;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

/**
 *
 * @author MauricioAsenjo
 */
public class Ex01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Set <String> lista1 = new HashSet<String>();
        lista1.add("Victor");
        lista1.add("Mauricio");
        lista1.add("Gilberto");
        lista1.add("Cesar");
        lista1.add("Ana");
        lista1.add("Mauricio");
        
        System.out.println("HashSet       = " + lista1);

        Set <String> lista2 = new LinkedHashSet<String>();
        lista2.add("Victor");      
        lista2.add("Mauricio");
        lista2.add("Gilberto");
        lista2.add("Cesar");
        lista2.add("Ana");
        lista2.add("Mauricio");
        
        System.out.println("LinkedHashSet = " + lista2);

        Set <String> lista3 = new TreeSet<String>();
        lista3.add("Victor");
        lista3.add("Mauricio");
        lista3.add("Gilberto");
        lista3.add("Cesar");
        lista3.add("Ana");
        lista3.add("Mauricio");
        
        System.out.println("TreeSet       = " + lista3);

    }
    
}
