/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Mauricio
 */
public class TestesUnitarios {
    Dados dados = new Dados();
        
    public TestesUnitarios() {
    }
    
    @Test
    public void teste01() {
        boolean esperado = true;
        dados.setDado1("");
        dados.setDado2("");
        dados.setDado3("");
        dados.setDado4("");
        TesteBLL.validaDados(dados);
        //assertEquals(O que é esperado, o que retorna)
        assertEquals(esperado, Erro.getErro());
    }

    @Test
    public void teste02() {
        boolean esperado = true;
        dados.setDado1("Maurício");
        dados.setDado2("");
        dados.setDado3("");
        dados.setDado4("");
        TesteBLL.validaDados(dados);
        //assertEquals(O que é esperado, o que retorna)
        assertEquals(esperado, Erro.getErro());
    }

    @Test
    public void teste03() {
        boolean esperado = true;
        dados.setDado1("Maurício");
        dados.setDado2("doze");
        dados.setDado3("");
        dados.setDado4("");
        TesteBLL.validaDados(dados);
        //assertEquals(O que é esperado, o que retorna)
        assertEquals(esperado, Erro.getErro());
    }
    
    @Test
    public void teste04() {
        boolean esperado = true;
        dados.setDado1("Maurício");
        dados.setDado2("12.4");
        dados.setDado3("");
        dados.setDado4("");
        TesteBLL.validaDados(dados);
        //assertEquals(O que é esperado, o que retorna)
        assertEquals(esperado, Erro.getErro());
    }
    
    @Test
    public void teste05() {
        boolean esperado = true;
        dados.setDado1("Maurício");
        dados.setDado2("12");
        dados.setDado3("12.4");
        dados.setDado4("7");
        TesteBLL.validaDados(dados);
        //assertEquals(O que é esperado, o que retorna)
        assertEquals(esperado, Erro.getErro());
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
