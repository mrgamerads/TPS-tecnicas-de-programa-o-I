/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mauricio
 */
public class TesteBLL {

public static void validaDados(Dados dados)
{
    Erro.setErro(false);
    if (dados.getDado1().equals(""))
    {
        Erro.setErro("O campo Dado1 é de preenchimento obrigatório..."); return;
    }

    if (dados.getDado2().equals(""))
    {
        Erro.setErro("O campo Dado2 é de preenchimento obrigatório..."); return;
    }
    else
    {
        try
        {
          Integer.parseInt(dados.getDado2());
        }
        catch (Exception e)
        {
          Erro.setErro("O campo Dado2 deve ser inteiro!"); return;
        }
    }
    
    if (dados.getDado3().equals(""))
    {
        Erro.setErro("O campo Dado3 é de preenchimento obrigatório..."); return;
    }
    else
    {
        try
        {
          Float.parseFloat(dados.getDado3());
        }
        catch (Exception e)
        {
          Erro.setErro("O campo Dado3 deve ser float!"); return;
        }
    }
    
    if (dados.getDado4().equals(""))
    {
        Erro.setErro("O campo Dado4 é de preenchimento obrigatório..."); return;
    }
        else
    {
        try
        {
          Integer.parseInt(dados.getDado4());
        }
        catch (Exception e)
        {
          Erro.setErro("O campo Dado4 deve ser inteiro!"); return;
        }
        if (Integer.parseInt(dados.getDado4()) <= 0)
        {
          Erro.setErro("O campo Dado4 deve ser maior que zero!"); return;
        }
    }

}
}