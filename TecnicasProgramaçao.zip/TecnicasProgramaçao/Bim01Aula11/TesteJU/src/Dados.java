/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mauricio
 */
public class Dados {
    private String dado1;   
    private String dado2;
    private String dado3;
    private String dado4;
    
    public void setDado1(String _dado1) {dado1 = _dado1;}
    public void setDado2(String _dado2) {dado2 = _dado2;}
    public void setDado3(String _dado3) {dado3 = _dado3;}
    public void setDado4(String _dado4) {dado4 = _dado4;}
    
    public String getDado1() { return dado1; }
    public String getDado2() { return dado2; }
    public String getDado3() { return dado3; }
    public String getDado4() { return dado4; }   
}
