public class Ex15
  {
  public static void main(String[] args)
    {
    int x=2;
    int i=1;

    do
      {
      System.out.println(x + " * " + i + " = " + x*i);
      ++i;
      }
    while(i<11);
    }
  }