public class Ex14
  {
  public static void main(String[] args)
    {
    int x=2;
    int i=1;

    while(i<11)
      {
      System.out.println(x + " * " + i + " = " + x*i);
      ++i;
      }
    }
  }