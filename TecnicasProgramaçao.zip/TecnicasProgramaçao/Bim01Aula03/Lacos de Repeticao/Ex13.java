public class Ex13
  {
  public static void main(String[] args)
    {
    int x=2;
    int i=1;

    for(;i<11;)
      {
      System.out.println(x + " * " + i + " = " + x*i);
      ++i;
      }
    }
  }