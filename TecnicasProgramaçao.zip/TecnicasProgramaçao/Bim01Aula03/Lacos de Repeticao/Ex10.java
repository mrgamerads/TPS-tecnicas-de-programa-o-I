public class Ex10
  {
  public static void main(String[] args)
    {
    int x=2;

    for (int i=1;i<11;++i)
      System.out.println(x + " * " + i + " = " + x*i);

    System.out.println("Ao final...");
    System.out.println("x = " + x);
    System.out.println("i = " + i);
    }
  }