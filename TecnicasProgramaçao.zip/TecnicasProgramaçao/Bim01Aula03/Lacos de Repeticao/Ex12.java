public class Ex12
  {
  public static void main(String[] args)
    {
    int x=2;
    int i=1;

    for(;i<11;++i)
      System.out.println(x + " * " + i + " = " + x*i);

    System.out.println("Ao final...");
    System.out.println("x = " + x);
    System.out.println("i = " + i);
    }
  }